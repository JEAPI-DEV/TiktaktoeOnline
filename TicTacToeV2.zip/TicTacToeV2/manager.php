<?php

// DELETE FROM messages WHERE date < (CURDATE() - INTERVAL 7 DAY);

$server = "YOUR SERVERADDRESS";
$user = "YOUR USER";
$pass = "YOUR PASSWORD";
$database = "YOUR DATABASE";

$conn = mysqli_connect($server, $user, $pass, $database);

function tokengen($length) {
    $random = '';
    for ($i = 0; $i < $length; $i++) {
        $random .= chr(rand(ord('0'), ord('9')));
    }
    return $random;
}


#host area
if (isset($_POST['hostrequest']))
{

    $sql = "DELETE FROM `tiktaktoe` WHERE date < (CURDATE() - INTERVAL 2 DAY)";
    mysqli_query($conn, $sql);
	#$date = date("Y-m-d h:i:sa");
    $playername1 = $_POST['hostrequest'];
	
	$token = tokengen(6);
    
    file_put_contents('session.log', $playername1 . "\n\n", FILE_APPEND);
	
    $sql = "INSERT INTO `tiktaktoe`(`token_id`, `playername1`) VALUES ('$token','$playername1')";
	mysqli_query($conn, $sql);	echo $token;
}


if (isset($_POST['hostcheckrequest']))
{
	#$date = date("Y-m-d h:i:sa");
    $token = $_POST['hostcheckrequest'];
	$sql = "SELECT * FROM tiktaktoe WHERE `token_id`='$token'";
	$result = mysqli_query($conn, $sql);
	$row = mysqli_fetch_assoc($result);			
		if(!empty($row['playername2'])){
            echo $row['playername2'];
        }else
        {
            echo "null";
        }
	
	
}

#client area
if (isset($_POST['clientrequest']))
{
	#$date = date("Y-m-d h:i:sa");
    $stringnotsplited = $_POST['clientrequest'];
	$splittedarr = explode("|", $stringnotsplited);
    $token = $splittedarr[0];
    $playername2 = $splittedarr[1];

	$sql = "UPDATE `tiktaktoe` SET `playername2`='$playername2' WHERE `token_id`=$token";
	mysqli_query($conn, $sql);

    $sql = "SELECT * FROM `tiktaktoe` WHERE `token_id`=$token";
    $result = mysqli_query($conn, $sql);
	$row = mysqli_fetch_assoc($result);		
    if ($result->num_rows > 0) {
        echo $row['playername1'];
    }else{
        echo "null";
    }	
}

#getmove

if (isset($_POST['getmove']))
{
	#$date = date("Y-m-d h:i:sa");
    $token = $_POST['getmove'];

	$sql = "SELECT * FROM tiktaktoe WHERE `token_id`=$token";
	$result = mysqli_query($conn, $sql);
	$row = mysqli_fetch_assoc($result);			
	if(!empty($row['current_move'])){
        echo $row['current_move'];
    }else
    {
        echo "null";
    }	
}

if (isset($_POST['setmove']))
{
	#$date = date("Y-m-d h:i:sa");
    $stringnotsplited = $_POST['setmove'];
	$splittedarr = explode("|", $stringnotsplited);
    $token = $splittedarr[0];
    $move = $splittedarr[1];

	$sql = "UPDATE `tiktaktoe` SET `current_move`='$move' WHERE `token_id`=$token";
	mysqli_query($conn, $sql);		
	echo "done";
	
}




