using System.IO;
using System.Net;
using System.Threading;
using System;
namespace TicTacToeV2
{
	public class ColorSettings
	{
		public static ConsoleColor forgroundcolor = ConsoleColor.White;
		public static ConsoleColor backgroundcolor = ConsoleColor.Black;
		private static string filepath = "colorconfig.txt";

		public static void SelectOption()
		{
			bool loop = true;
			Console.Clear();

			while (loop)
			{
				Console.WriteLine("Forground : Black | White | Blue | Cyan | Gray");
				Console.WriteLine("Green | Mangenta | Red | Yellow");

				string fc = Console.ReadLine().ToLower();

				switch (fc)
				{
					case "black":
						loop = false;
						forgroundcolor = ConsoleColor.Black;
						break;
					case "white":
						loop = false;
						forgroundcolor = ConsoleColor.White;
						break;
					case "blue":
						loop = false;
						forgroundcolor = ConsoleColor.Blue;
						break;
					case "cyan":
						loop = false;
						forgroundcolor = ConsoleColor.Cyan;
						break;
					case "gray":
						loop = false;
						forgroundcolor = ConsoleColor.Gray;
						break;
					case "green":
						loop = false;
						forgroundcolor = ConsoleColor.Green;
						break;
					case "magenta":
						loop = false;
						forgroundcolor = ConsoleColor.Magenta;
						break;
					case "red":
						loop = false;
						forgroundcolor = ConsoleColor.Red;
						break;
					case "yellow":
						loop = false;
						forgroundcolor = ConsoleColor.Yellow;
						break;
					default:
						Console.WriteLine("\nInvalid input please select a valid Color");
						Thread.Sleep(3000);
						Console.Clear();
						break;
				}
			}

			loop = true;
			Console.Clear();

			while (loop)
			{
				Console.WriteLine("Background : Black | White | Blue | Cyan | Gray");
				Console.WriteLine("Green | Mangenta | Red | Yellow");

				string bc = Console.ReadLine().ToLower();

				switch (bc)
				{
					case "black":
						loop = false;
						backgroundcolor = ConsoleColor.Black;
						break;
					case "white":
						loop = false;
						backgroundcolor = ConsoleColor.White;
						break;
					case "blue":
						loop = false;
						backgroundcolor = ConsoleColor.Blue;
						break;
					case "cyan":
						loop = false;
						backgroundcolor = ConsoleColor.Cyan;
						break;
					case "gray":
						loop = false;
						backgroundcolor = ConsoleColor.Gray;
						break;
					case "green":
						loop = false;
						backgroundcolor = ConsoleColor.Green;
						break;
					case "magenta":
						loop = false;
						backgroundcolor = ConsoleColor.Magenta;
						break;
					case "red":
						loop = false;
						backgroundcolor = ConsoleColor.Red;
						break;
					case "yellow":
						loop = false;
						backgroundcolor = ConsoleColor.Yellow;
						break;
					default:
						Console.WriteLine("\nInvalid input please select a valid Color");
						Thread.Sleep(3000);
						Console.Clear();
						break;
				}
			}
			
			applyconfig();

		}


		public static void applyconfig()
		{
			File.WriteAllText(filepath, String.Empty);
			using (StreamWriter sw = File.AppendText(filepath))
			{
				sw.WriteLine(forgroundcolor);
				sw.WriteLine(backgroundcolor);
			}
		}

		public static void ConfigManager()
		{
			if (!File.Exists(filepath))
			{
				using (StreamWriter sw = File.AppendText(filepath))
				{
					sw.WriteLine("white");
					sw.WriteLine("black");
				}
			}


			string[] lines = File.ReadAllLines(filepath);

			switch (Convert.ToString(lines[0]).ToLower())
			{
				case "black":
					forgroundcolor = ConsoleColor.Black;
					break;
				case "white":
					forgroundcolor = ConsoleColor.White;
					break;
				case "blue":
					forgroundcolor = ConsoleColor.Blue;
					break;
				case "cyan":
					forgroundcolor = ConsoleColor.Cyan;
					break;
				case "gray":
					forgroundcolor = ConsoleColor.Gray;
					break;
				case "green":
					forgroundcolor = ConsoleColor.Green;
					break;
				case "magenta":
					forgroundcolor = ConsoleColor.Magenta;
					break;
				case "red":
					forgroundcolor = ConsoleColor.Red;
					break;
				case "yellow":
					forgroundcolor = ConsoleColor.Yellow;
					break;
				default: 
					break;
			}

			switch (Convert.ToString(lines[1]).ToLower())
			{
				case "black":
					backgroundcolor = ConsoleColor.Black;
					break;
				case "white":
					backgroundcolor = ConsoleColor.White;
					break;
				case "blue":
					backgroundcolor = ConsoleColor.Blue;
					break;
				case "cyan":
					backgroundcolor = ConsoleColor.Cyan;
					break;
				case "gray":
					backgroundcolor = ConsoleColor.Gray;
					break;
				case "green":
					backgroundcolor = ConsoleColor.Green;
					break;
				case "magenta":
					backgroundcolor = ConsoleColor.Magenta;
					break;
				case "red":
					backgroundcolor = ConsoleColor.Red;
					break;
				case "yellow":
					backgroundcolor = ConsoleColor.Yellow;
					break;
				default: 
					break;	
			}



		}
	}
}