﻿using System.Drawing;
namespace TicTacToeV2
{
	using System;

	/// <summary>
	/// FUNCTIONS OF GAME CLASS
	/// 
	/// RUN : is the start point of the programm and loops the checks
	/// DISPLAY : Displayes the Board
	/// MOVE : is the move manager for better field selection in the Board
	/// SETMOVE : Manages the current and new Player and set's the selected field for the player
	/// GAMEOVER : displayes the win message for the winner if the bool win is true for the symbol
	/// DRAW : displayes a draw message if isFull is true , result nobody wins
	/// RESTARTGAME : shows the user a screen where he can choose between quitting or revenge
	/// </summary>

	public class OfflineGame
	{
		public char[,] Board { get; private set; }
		private static int currentPlayer = 1;
		private static int winsp1 = 0;
		private static int winsp2 = 0;

		public OfflineGame()
		{
			this.Board = new char[3, 3]
			{
					{ ' ', ' ', ' ', },
					{ ' ', ' ', ' ', },
					{ ' ', ' ', ' ', },
			};
		}

		public void Execute()
		{
			do
			{
				move();
				if (win('X')) { winsp1++; gameOver("Player1"); }
				if (win('O')) { winsp2++; gameOver("Player2"); }
				if (isFull()) { Draw(); }

			} while (true);
		}

		private void Display()
		{
			Console.ForegroundColor = ColorSettings.forgroundcolor;
			Console.BackgroundColor = ColorSettings.backgroundcolor;
			Console.Clear();
			Console.WriteLine();
			Console.WriteLine($" {Board[0, 0]}  |  {Board[0, 1]}  |  {Board[0, 2]}");
			Console.WriteLine("    |     |");
			Console.WriteLine(" ---|-----|---");
			Console.WriteLine("    |     |");
			Console.WriteLine($" {Board[1, 0]}  |  {Board[1, 1]}  |  {Board[1, 2]}");
			Console.WriteLine("    |     |");
			Console.WriteLine(" ---|-----|---");
			Console.WriteLine("    |     |");
			Console.WriteLine($" {Board[2, 0]}  |  {Board[2, 1]}  |  {Board[2, 2]}");
			Console.Title = $"TiktakToe Player : {currentPlayer}";
			Console.WriteLine("\nPlayer {0} is on the turn", currentPlayer);
			Console.WriteLine($"\n\nCONTROLS:\n- Move: Arrowkeys\n- Confirm: Enter or Space\n- Exit: Esc");
			Console.WriteLine();
		}

		private void move()
		{

			var (row, column) = (0, 0);
			bool moved = false;
			Console.Clear();
			Display();
			while (!moved)
			{
				Console.WriteLine();
				Console.SetCursorPosition(column * 6 + 1, row * 4 + 1);
				switch (Console.ReadKey(true).Key)
				{
					case ConsoleKey.UpArrow: row = row <= 0 ? 2 : row - 1; break;
					case ConsoleKey.DownArrow: row = row >= 2 ? 0 : row + 1; break;
					case ConsoleKey.LeftArrow: column = column <= 0 ? 2 : column - 1; break;
					case ConsoleKey.RightArrow: column = column >= 2 ? 0 : column + 1; break;
					case ConsoleKey.Enter:
						moved = setmove(row, column);
						break;
					case ConsoleKey.Spacebar:
						moved = setmove(row, column);
						break;
					case ConsoleKey.Escape:
						Environment.Exit(0);
						break;
				}
			}
		}

		private bool setmove(int Row, int Colum)
		{
			if (Board[Row, Colum] == ' ')
			{
				if (currentPlayer == 1)
				{
					Board[Row, Colum] = 'X';
					currentPlayer++;
				}
				else
				{
					Board[Row, Colum] = 'O';
					currentPlayer--;
				}
			}
			else
			{
				return false;
			}
			return true;
		}

		private void gameOver(string Player)
		{
			Display();
			Console.ForegroundColor = ConsoleColor.Black;
			Console.BackgroundColor = ConsoleColor.Red;
			Console.WriteLine("\n{0} wins, good job", Player);
			Console.WriteLine("Press any Key...");
			Console.ReadKey();
			RestartGame();
		}

		bool win(char symbol) =>
			Board[0, 0] == symbol && Board[1, 0] == symbol && Board[2, 0] == symbol ||
			Board[0, 1] == symbol && Board[1, 1] == symbol && Board[2, 1] == symbol ||
			Board[0, 2] == symbol && Board[1, 2] == symbol && Board[2, 2] == symbol ||
			Board[0, 0] == symbol && Board[0, 1] == symbol && Board[0, 2] == symbol ||
			Board[1, 0] == symbol && Board[1, 1] == symbol && Board[1, 2] == symbol ||
			Board[2, 0] == symbol && Board[2, 1] == symbol && Board[2, 2] == symbol ||
			Board[0, 0] == symbol && Board[1, 1] == symbol && Board[2, 2] == symbol ||
			Board[2, 0] == symbol && Board[1, 1] == symbol && Board[0, 2] == symbol;

		bool isFull() =>
			Board[0, 0] != ' ' && Board[1, 0] != ' ' && Board[2, 0] != ' ' &&
			Board[0, 1] != ' ' && Board[1, 1] != ' ' && Board[2, 1] != ' ' &&
			Board[0, 2] != ' ' && Board[1, 2] != ' ' && Board[2, 2] != ' ';

		public void Draw()
		{
			Display();
			Console.ForegroundColor = ConsoleColor.Black;
			Console.BackgroundColor = ConsoleColor.Cyan;
			Console.WriteLine("\nDraw everyone Loses");
			Console.WriteLine("Press any Key...");
			Console.ReadKey();
			RestartGame();
		}

		public void RestartGame()
		{
			Console.ForegroundColor = ColorSettings.forgroundcolor;
			Console.BackgroundColor = ColorSettings.backgroundcolor;
			Console.Clear();
			Console.WriteLine("Do u want to exit or Restart\n");
			Console.WriteLine("------------------------------\n");
			Console.WriteLine($"Player1 : {winsp1}    |    Player2 : {winsp2}\n");
			Console.WriteLine("------------------------------\n");
			Console.WriteLine("Press R <-- to Restart\nPress Q <-- to Quit");
			switch (Console.ReadKey(true).Key)
			{
				case ConsoleKey.R:
					OfflineGame offline = new OfflineGame();
					offline.Execute();

					break;
				case ConsoleKey.Q:
					Environment.Exit(0);
					break;
				default:
					Environment.Exit(0);
					break;
			}
		}
	}
}
