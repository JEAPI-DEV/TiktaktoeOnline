﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace TicTacToeV2
{
	public class MultiplayerPublic
	{
		private string token_id;
		private string playername1;
		private string playername2;
		private string mymove;
		private string request;
		public char[,] Board { get; private set; }
		private static int currentPlayer = 1;
		private static int player = 0;
		Networking net = new Networking();

		public MultiplayerPublic()
		{
			this.Board = new char[3, 3]
			{
					{ ' ', ' ', ' ', },
					{ ' ', ' ', ' ', },
					{ ' ', ' ', ' ', },
			};
		}

		// COULD BE SKIPED BUT LIKE IT MORE THEN ALWAYS USING THAT STRAGE SPLIT METHOD
		public static string[] explode(string separator, string source)
		{
			// SPLITS THE STRING BY THE SPERATOR AND RETURNS IT AS A STRING ARRAY
			return source.Split(new string[] { separator }, StringSplitOptions.None);
		}

		public void Execute()
		{
			string text = @"                                _____ _____ _   _______ ___   _   _______ _____ _____ 
								|_   _|_   _| | / /_   _/ _ \ | | / /_   _|  _  |  ___|
								  | |   | | | |/ /  | |/ /_\ \| |/ /  | | | | | | |__  
								  | |   | | |    \  | ||  _  ||    \  | | | | | |  __| 
								  | |  _| |_| |\  \ | || | | || |\  \ | | \ \_/ / |___ 
								  \_/  \___/\_| \_/ \_/\_| |_/\_| \_/ \_/  \___/\____/                             
";

			string[] options = new string[] { "Host", "Join", "Exit" };
			Menu menu = new Menu("*", " >> ", " << ", text, options, true);
			int selected = menu.Run();

			Console.Clear();
			Console.ForegroundColor = ColorSettings.forgroundcolor;
			Console.BackgroundColor = ColorSettings.backgroundcolor;

			switch (selected)
			{
				case 0:
					Host();
					break;
				case 1:
					Join();
					break;
				case 3:
					Environment.Exit(0);
					break;
			}
		}


		#region NETWORKING STUFF DON'T TOUCH IT CAN BITE XD
		public void Host()
		{
			#region (CREATE SERVER AND WAIT FOR PLAYER)
			player = 1;

			Console.WriteLine("Enter how you wanna be called");
			playername1 = Console.ReadLine();
			// CREATE SERVER AND RECIEVE TOKEN FOR THE GAME
			token_id = net.upload($"{playername1}", "hostrequest");

			Console.Title = $"Your Token: {token_id} | Your Name: {playername1}";

			while (net.upload($"{token_id}", "hostcheckrequest") == "null")
			{
				Console.Clear();
				Console.WriteLine($"Waiting for another Player .\n\n\nYour Token: {token_id}");
				Thread.Sleep(500);
				Console.Clear();
				Console.WriteLine($"Waiting for another Player ..\n\n\nYour Token: {token_id}");
				Thread.Sleep(1000);
				Console.Clear();
				Console.WriteLine($"Waiting for another Player ...\n\n\nYour Token: {token_id}");
				Thread.Sleep(2000);
			}
			playername2 = net.upload($"{token_id}", "hostcheckrequest");
			Console.Title = $"Your Token: {token_id} | Your Name: {playername1} | Enemy Name: {playername2}";
			#endregion

			while (true)
			{
				simplecheck();
				// ALLOW PLAYER MAKE MOVE IF CURRENT MOVE IS NOT EQUAL TO YOUR LAST MOVE
				// IN ORDER TO MAKE A MOVE
				if (mymove != net.upload($"{token_id}", "getmove"))
				{
					mymove = move();
					Display();
					net.upload($"{token_id}|{mymove}", "setmove");
				}

				simplecheck();

				requestchecker();
			}
		}

		public void Join()
		{

			#region (PlayerConnet)	
			player = 2;

			Console.WriteLine("Enter how you want to be called");
			playername2 = Console.ReadLine();

			do
			{
				Console.WriteLine("Enter valid token");
				token_id = Console.ReadLine();
				playername1 = net.upload($"{token_id}|{playername2}", "clientrequest");
			} while (playername1 == "null");
			Console.Title = $"Your Token: {token_id} | Your Name: {playername2} | Enemy Name: {playername1}";
			#endregion


			while (true)
			{
				simplecheck();

				// ALLOW PLAYER MAKE MOVE IF CURRENT MOVE IS NOT EQUAL TO YOUR LAST MOVE AND CURRENT MOVE IS NOT ALLOWED TO BE NULL
				// IN ORDER TO MAKE A MOVE
				if (mymove != net.upload($"{token_id}", "getmove") && net.upload($"{token_id}", "getmove") != "null")
				{
					mymove = move();
					Display();
					net.upload($"{token_id}|{mymove}", "setmove");
				}

				simplecheck();

				requestchecker();
			}
		}


		private void requestchecker()
		{
			do
			{
				// AVOID SERVER DDOS PROTECTION
				Thread.Sleep(500);
				// -----------------------------

				// REQUEST SERVER DATA AND CHECKS IF THE MOVE IS NOT EQUAL TO YOUR LAST MOVE ALSO THE SERVER IS NOT ALLOWED TO BE NULL
				request = net.upload($"{token_id}", "getmove");
				Console.WriteLine(request + " | " + mymove);
				if (mymove != request && request != "null")
				{
					// SPLITS THE STRING INTO AN ARRAY BY GIVEN SEPERATOR
					string[] atr = explode(",", request);
					setmove(Convert.ToInt32(atr[0]), Convert.ToInt32(atr[1]));

					// DOUBLE CHECK IF SOMETHING FAILES
					if (Board[Convert.ToInt32(atr[0]), Convert.ToInt32(atr[1])] == ' ')
					{
						setmove(Convert.ToInt32(atr[0]), Convert.ToInt32(atr[1]));
					}
				}
			} while (mymove == request);
		}


		#endregion


		#region GAME PART OF THE MULTIPLAYER
		private void Display()
		{
			Console.Clear();
			Console.ForegroundColor = ColorSettings.forgroundcolor;
			Console.BackgroundColor = ColorSettings.backgroundcolor;
			Console.WriteLine();
			Console.WriteLine($" {Board[0, 0]}  |  {Board[0, 1]}  |  {Board[0, 2]}");
			Console.WriteLine("    |     |");
			Console.WriteLine(" ---|-----|---");
			Console.WriteLine("    |     |");
			Console.WriteLine($" {Board[1, 0]}  |  {Board[1, 1]}  |  {Board[1, 2]}");
			Console.WriteLine("    |     |");
			Console.WriteLine(" ---|-----|---");
			Console.WriteLine("    |     |");
			Console.WriteLine($" {Board[2, 0]}  |  {Board[2, 1]}  |  {Board[2, 2]}");

			//Console.Title = $"TiktakToe Current Player : {currentPlayer}  |  You are Player : {player}";
			Console.WriteLine("\nPlayer {0} is on the turn\n You are Player: {1}", currentPlayer, player);
			Console.WriteLine($"\n\nCONTROLS:\n- Move: Arrowkeys\n- Confirm: Enter or Space\n- Exit: Esc");
			Console.WriteLine();
		}

		private void gameOver(int Player)
		{
			Display();
			Console.ForegroundColor = ConsoleColor.Black;
			Console.BackgroundColor = ConsoleColor.Red;

			if (Player == player)
			{
				Console.WriteLine("\nPlayer{0} wins, good job", Player);
			}
			else
			{
				Console.WriteLine("\nPlayer{0} wins, you win next time", Player);
			}


			Console.WriteLine("Press any Key...");
			Console.ReadKey();
			Environment.Exit(0);
		}

		private void simplecheck()
		{
			Display();
			if (win('X')) { gameOver(1); }
			if (win('O')) { gameOver(2); }
			if (isFull()) { Draw(); }
		}

		bool win(char symbol) =>
			Board[0, 0] == symbol && Board[1, 0] == symbol && Board[2, 0] == symbol ||
			Board[0, 1] == symbol && Board[1, 1] == symbol && Board[2, 1] == symbol ||
			Board[0, 2] == symbol && Board[1, 2] == symbol && Board[2, 2] == symbol ||
			Board[0, 0] == symbol && Board[0, 1] == symbol && Board[0, 2] == symbol ||
			Board[1, 0] == symbol && Board[1, 1] == symbol && Board[1, 2] == symbol ||
			Board[2, 0] == symbol && Board[2, 1] == symbol && Board[2, 2] == symbol ||
			Board[0, 0] == symbol && Board[1, 1] == symbol && Board[2, 2] == symbol ||
			Board[2, 0] == symbol && Board[1, 1] == symbol && Board[0, 2] == symbol;

		bool isFull() =>
			Board[0, 0] != ' ' && Board[1, 0] != ' ' && Board[2, 0] != ' ' &&
			Board[0, 1] != ' ' && Board[1, 1] != ' ' && Board[2, 1] != ' ' &&
			Board[0, 2] != ' ' && Board[1, 2] != ' ' && Board[2, 2] != ' ';

		public void Draw()
		{
			Display();
			Console.ForegroundColor = ConsoleColor.Black;
			Console.BackgroundColor = ConsoleColor.Cyan;
			Console.WriteLine("\nDraw everyone Loses");
			Console.WriteLine("Press any Key...");
			Console.ReadKey();
			Environment.Exit(0);
		}

		private string move()
		{

			var (row, column) = (0, 0);
			bool moved = false;
			Console.Clear();
			Display();
			while (!moved)
			{
				Console.WriteLine();
				Console.SetCursorPosition(column * 6 + 1, row * 4 + 1);
				switch (Console.ReadKey(true).Key)
				{
					case ConsoleKey.UpArrow: row = row <= 0 ? 2 : row - 1; break;
					case ConsoleKey.DownArrow: row = row >= 2 ? 0 : row + 1; break;
					case ConsoleKey.LeftArrow: column = column <= 0 ? 2 : column - 1; break;
					case ConsoleKey.RightArrow: column = column >= 2 ? 0 : column + 1; break;
					case ConsoleKey.Enter:
						moved = setmove(row, column);
						break;
					case ConsoleKey.Spacebar:
						moved = setmove(row, column);
						break;
					case ConsoleKey.Escape:
						moved = setmove(row, column);
						break;
				}
			}
			return $"{row},{column}";
		}

		private bool setmove(int Row, int Colum)
		{
			if (Board[Row, Colum] == ' ')
			{
				if (currentPlayer == 1)
				{
					Board[Row, Colum] = 'X';
					currentPlayer++;
				}
				else if (currentPlayer == 2)
				{
					Board[Row, Colum] = 'O';
					currentPlayer--;
				}
			}
			else
			{
				return false;
			}
			return true;
		}

		#endregion


	}
}
