﻿using System.Drawing;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace TicTacToeV2
{
	public class MultiplayerLocal
	{
		//private string mypublicAdress = new System.Net.WebClient().DownloadString("https://api.ipify.org");
		private string myprivateAdress = GetLocalIPAddress();
		public char[,] Board { get; private set; }
		private static int currentPlayer = 1;
		private static int player = 0;

		public MultiplayerLocal()
		{
			this.Board = new char[3, 3]
			{
					{ ' ', ' ', ' ', },
					{ ' ', ' ', ' ', },
					{ ' ', ' ', ' ', },
			};
		}

		public void Execute()
		{
			string text = @"                                _____ _____ _   _______ ___   _   _______ _____ _____ 
								|_   _|_   _| | / /_   _/ _ \ | | / /_   _|  _  |  ___|
								  | |   | | | |/ /  | |/ /_\ \| |/ /  | | | | | | |__  
								  | |   | | |    \  | ||  _  ||    \  | | | | | |  __| 
								  | |  _| |_| |\  \ | || | | || |\  \ | | \ \_/ / |___ 
								  \_/  \___/\_| \_/ \_/\_| |_/\_| \_/ \_/  \___/\____/                             
";

			string[] options = new string[] { "Host", "Join", "Exit" };
			Menu menu = new Menu("*", " >> ", " << ", text, options, true);
			int selected = menu.Run();

			switch (selected)
			{
				case 0:
					Host();
					break;
				case 1:
					Join();
					break;
				case 2:
					break;
				case 3:
					Environment.Exit(0);
					break;
			}
		}


		# region NETWORKING STUFF DON'T TOUCH IT CAN BITE XD
		public void Host()
		{
			Console.Clear();
			Console.ForegroundColor = ColorSettings.forgroundcolor;
			Console.BackgroundColor = ColorSettings.backgroundcolor;
			player = 2;
			//Console.WriteLine("Your Public IP: " + mypublicAdress); NEEDS PORT TO BE OPENED IN ORDER TO PLAY PUBLICLY
			Console.WriteLine("My Private IP: " + myprivateAdress);
			Console.OutputEncoding = Encoding.UTF8;

			int recv;
			// Buffer to store the data bytes.
			byte[] data = new byte[1024];
			IPEndPoint ipep = new IPEndPoint(IPAddress.Any, 9050);

			Socket newsock = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);

			newsock.Bind(ipep);

			newsock.Listen(10);

			Console.WriteLine("Waiting for another player...");

			Socket client = newsock.Accept();

			IPEndPoint clientep = (IPEndPoint)client.RemoteEndPoint;

			Console.WriteLine("Connected with {0} at port {1}", clientep.Address, clientep.Port);

			string welcome = "You are connected";

			data = Encoding.UTF8.GetBytes(welcome);

			client.Send(data, data.Length, SocketFlags.None);
			while (true)
			{
				simplecheck();


				if (currentPlayer == player)
				{
					string location = move();
					Display();
					client.Send(Encoding.UTF8.GetBytes(location));
				}
				
				simplecheck();

				data = new byte[1024];
				recv = client.Receive(data);
				string stringData = Encoding.UTF8.GetString(data, 0, recv);

				//byte[] utf8string = System.Text.Encoding.UTF8.GetBytes(stringData);
				string[] stuff = stringData.Split(new string[] { "|" }, StringSplitOptions.None);
				setmove(Convert.ToInt32(stuff[0]), Convert.ToInt32(stuff[1]));


			}

			Console.WriteLine("Disconnected from {0}", clientep.Address);

			client.Close();

			newsock.Close();

			Console.ReadLine();

		}

		public void Join()
		{
			Console.Clear();
			Console.ForegroundColor = ColorSettings.forgroundcolor;
			Console.BackgroundColor = ColorSettings.backgroundcolor;
			player = 1;
			Console.WriteLine("Enter IP address");
			string jointoip = Console.ReadLine();
			
			Console.OutputEncoding = Encoding.UTF8;

			byte[] data = new byte[1024];
			string stringData;

			IPEndPoint ipep = new IPEndPoint(IPAddress.Parse(jointoip), 9050);

			Socket server = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);

			try
			{
				server.Connect(ipep);

			}
			catch (SocketException e)
			{
				Console.WriteLine("Unable to connect to server.");

				Console.WriteLine(e.ToString());

				return;
			}

			int recv = server.Receive(data);

			stringData = Encoding.UTF8.GetString(data, 0, recv);

			Console.WriteLine(stringData);

			while (true)
			{
				// READ WRITE WAIT REPEAT

				simplecheck();

				if (currentPlayer == player)
				{
					string location = move();
					Display();
					server.Send(Encoding.UTF8.GetBytes(location));
				}
				
				simplecheck();

				data = new byte[1024];
				recv = server.Receive(data);
				stringData = Encoding.UTF8.GetString(data, 0, recv);
				Display();

				//byte[] utf8string = System.Text.Encoding.UTF8.GetBytes(stringData);
				string[] stuff = stringData.Split(new string[] { "|" }, StringSplitOptions.None);
				setmove(Convert.ToInt32(stuff[0]), Convert.ToInt32(stuff[1]));
				

			   
			}

			Console.WriteLine("Disconnecting from server...");

			server.Shutdown(SocketShutdown.Both);

			server.Close();

			Console.WriteLine("Disconnected!");

			Console.ReadLine();

		
		}
		
		private void simplecheck()
		{
			Display();
			if (win('X')) { gameOver(1); }
			if (win('O')) { gameOver(2); }
			if (isFull()) { Draw(); }
		}

		public static string GetLocalIPAddress()
		{
			var host = Dns.GetHostEntry(Dns.GetHostName());
			foreach (var ip in host.AddressList)
			{
				if (ip.AddressFamily == AddressFamily.InterNetwork)
				{
					return ip.ToString();
				}
			}
			return "error";
		}
		#endregion



		#region GAME PART OF THE MULTIPLAYER
		private void Display()
		{
			Console.BackgroundColor = ColorSettings.backgroundcolor;
			Console.ForegroundColor = ColorSettings.forgroundcolor;
			Console.Clear();
			Console.WriteLine();
			Console.WriteLine($" {Board[0, 0]}  |  {Board[0, 1]}  |  {Board[0, 2]}");
			Console.WriteLine("    |     |");
			Console.WriteLine(" ---|-----|---");
			Console.WriteLine("    |     |");
			Console.WriteLine($" {Board[1, 0]}  |  {Board[1, 1]}  |  {Board[1, 2]}");
			Console.WriteLine("    |     |");
			Console.WriteLine(" ---|-----|---");
			Console.WriteLine("    |     |");
			Console.WriteLine($" {Board[2, 0]}  |  {Board[2, 1]}  |  {Board[2, 2]}");

			Console.Title = $"TiktakToe Current Player : {currentPlayer}  |  You are Player : {player}";
			Console.WriteLine("\nPlayer {0} is on the turn\n You are Player: {1}", currentPlayer, player);
			Console.WriteLine($"\n\nCONTROLS:\n- Move: Arrowkeys\n- Confirm: Enter or Space\n- Exit: Esc");
			Console.WriteLine();
		}

		private void gameOver(int Player)
		{
			Display();
			Console.ForegroundColor = ConsoleColor.Black;
			Console.BackgroundColor = ConsoleColor.Red;
  
			if(Player == player)
			{
				Console.WriteLine("\nPlayer{0} wins, good job", Player);
			}
			else
			{
				Console.WriteLine("\nPlayer{0} wins, you win next time", Player);
			}

			
			Console.WriteLine("Press any Key...");
			Console.ReadKey();
			Environment.Exit(0);
		}

		bool win(char symbol) =>
			Board[0, 0] == symbol && Board[1, 0] == symbol && Board[2, 0] == symbol ||
			Board[0, 1] == symbol && Board[1, 1] == symbol && Board[2, 1] == symbol ||
			Board[0, 2] == symbol && Board[1, 2] == symbol && Board[2, 2] == symbol ||
			Board[0, 0] == symbol && Board[0, 1] == symbol && Board[0, 2] == symbol ||
			Board[1, 0] == symbol && Board[1, 1] == symbol && Board[1, 2] == symbol ||
			Board[2, 0] == symbol && Board[2, 1] == symbol && Board[2, 2] == symbol ||
			Board[0, 0] == symbol && Board[1, 1] == symbol && Board[2, 2] == symbol ||
			Board[2, 0] == symbol && Board[1, 1] == symbol && Board[0, 2] == symbol;

		bool isFull() =>
			Board[0, 0] != ' ' && Board[1, 0] != ' ' && Board[2, 0] != ' ' &&
			Board[0, 1] != ' ' && Board[1, 1] != ' ' && Board[2, 1] != ' ' &&
			Board[0, 2] != ' ' && Board[1, 2] != ' ' && Board[2, 2] != ' ';

		public void Draw()
		{
			Display();
			Console.ForegroundColor = ConsoleColor.Black;
			Console.BackgroundColor = ConsoleColor.Cyan;
			Console.WriteLine("\nDraw everyone Loses");
			Console.WriteLine("Press any Key...");
			Console.ReadKey();
			Environment.Exit(0);
		}

		private string move()
		{

			var (row, column) = (0, 0);
			bool moved = false;
			Console.Clear();
			Display();
			while (!moved)
			{
				Console.WriteLine();
				Console.SetCursorPosition(column * 6 + 1, row * 4 + 1);
				switch (Console.ReadKey(true).Key)
				{
					case ConsoleKey.UpArrow: row = row <= 0 ? 2 : row - 1; break;
					case ConsoleKey.DownArrow: row = row >= 2 ? 0 : row + 1; break;
					case ConsoleKey.LeftArrow: column = column <= 0 ? 2 : column - 1; break;
					case ConsoleKey.RightArrow: column = column >= 2 ? 0 : column + 1; break;
					case ConsoleKey.Enter:
						moved = setmove(row, column);
						break;
					case ConsoleKey.Spacebar:
						moved = setmove(row, column);
						break;
					case ConsoleKey.Escape:
						moved = setmove(row, column);
						break;
				}
			}
			return $"{row}|{column}";
		}

		private bool setmove(int Row, int Colum)
		{
			if (Board[Row, Colum] == ' ')
			{
				if (currentPlayer == 1)
				{
					Board[Row, Colum] = 'X';
					currentPlayer++;
				}
				else if(currentPlayer == 2)
				{
					Board[Row, Colum] = 'O';
					currentPlayer--;
				}
			}
			else
			{
				return false;
			}
			return true;
		}

		#endregion

		
	}
}
