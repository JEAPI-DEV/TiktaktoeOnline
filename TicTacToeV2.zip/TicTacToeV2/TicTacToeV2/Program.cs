﻿namespace TicTacToeV2
{
	using System;

	/// <summary>
	/// CREDITS:
	/// Main Menu: Michael Hadley >> https://www.youtube.com/channel/UC_x9TgYAIFHj1ulXjNgZMpQ
	/// Tiktaktoe movement handler: ZacharyPatten >> https://github.com/ZacharyPatten/dotnet-console-games
	/// 
	/// Rest of the Project : JEAPI (Mateusz)  >> https://gefory.com
	/// </summary>

	class Program
	{
		static void Main(string[] args)
		{
			while (true)
			{
				ColorSettings.ConfigManager();
				string text = @"                                
								 _____ _____ _   _______ ___   _   _______ _____ _____ 
								|_   _|_   _| | / /_   _/ _ \ | | / /_   _|  _  |  ___|
								  | |   | | | |/ /  | |/ /_\ \| |/ /  | | | | | | |__  
								  | |   | | |    \  | ||  _  ||    \  | | | | | |  __| 
								  | |  _| |_| |\  \ | || | | || |\  \ | | \ \_/ / |___ 
								  \_/  \___/\_| \_/ \_/\_| |_/\_| \_/ \_/  \___/\____/                             
";

				string[] options = new string[] { "Singelplayer", "Multiplayer", "MultiplayerV2", "Options", "Exit" };
				Menu menu = new Menu("*", " >> ", " << ", text, options, true);
				int selected = menu.Run();

				switch (selected)
				{
					case 0:
						OfflineGame offline = new OfflineGame();
						offline.Execute();
						break;
					case 1:
						MultiplayerLocal loc = new MultiplayerLocal();
						loc.Execute();
						break;
					case 2:
						MultiplayerPublic pub = new MultiplayerPublic();
						pub.Execute();
						break;
					case 3:
						ColorSettings.SelectOption();
						break;
					case 4:
						Environment.Exit(0);
						break;
				}
			}
		}
	}
}
