﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace TicTacToeV2
{
	public class Networking
	{

		public string upload(string transferstring, string type)
		{
			try
			{
				//NEEDS TO BE CHANGED TO YOUR MANAGER / HANDLER URL
				HttpWebRequest req = (HttpWebRequest)WebRequest.Create("https://gefory.com/jeapi/tiktaktoe/manager.php");
				req.Method = "POST";
				string Data = type + "=" + transferstring;
				byte[] postBytes = Encoding.ASCII.GetBytes(Data);
				req.ContentType = "application/x-www-form-urlencoded";
				req.ContentLength = postBytes.Length;
				Stream requestStream = req.GetRequestStream();
				requestStream.Write(postBytes, 0, postBytes.Length);
				requestStream.Close();
				HttpWebResponse response = (HttpWebResponse)req.GetResponse();
				Stream resStream = response.GetResponseStream();

				var sr = new StreamReader(response.GetResponseStream());
				string responseText = sr.ReadToEnd();
				return responseText;
				
			}
			catch
			{
				return "OFFLINE";
			}
		}
	}
}
