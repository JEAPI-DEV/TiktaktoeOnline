﻿using System;

namespace TicTacToeV2
{
	public class Menu
	{
		private int SelectedIndex;
		private string[] Options;
		private string Prefixbeforeoption;
		private string Prefix;
		private string Suffix;
		private string Text;
		private bool Center;

		public Menu(string prefixbeforeoption, string prefix, string suffix, string text, string[] options, bool center)
		{
			Prefixbeforeoption = prefixbeforeoption;
			Prefix = prefix;
			Suffix = suffix;
			Text = text;
			Options = options;
			Center = center;
			SelectedIndex = 0;
		}

		private void DisplayOptions()
		{
			Console.ForegroundColor = ColorSettings.forgroundcolor;
			Console.BackgroundColor = ColorSettings.backgroundcolor;
			string prefixbeforeoption;
			Console.WriteLine(Text);

			for (int i = 0; i < Options.Length; i++)
			{
				if (i == SelectedIndex)
				{
					prefixbeforeoption = Prefixbeforeoption;
					Console.BackgroundColor = ConsoleColor.White;
					Console.ForegroundColor = ConsoleColor.Black;
				}
				else
				{
					prefixbeforeoption = " ";
					Console.ForegroundColor = ConsoleColor.White;
					Console.BackgroundColor = ConsoleColor.Black;
				}
				string toprint = $"{prefixbeforeoption}{Prefix}{Options[i]}{Suffix}";

				if (Center)
				{
					Console.SetCursorPosition((Console.WindowWidth - toprint.Length) / 2, Console.CursorTop);
				}

				Console.WriteLine(toprint);
			}
			Console.ResetColor();
		}

		public int Run()
		{
			ConsoleKey keypressed;
			do
			{
				Console.Clear();
				DisplayOptions();
				ConsoleKeyInfo keyinfo = Console.ReadKey(true);
				keypressed = keyinfo.Key;

				if (keypressed == ConsoleKey.UpArrow)
				{
					//Console.Beep(1000, 100);
					SelectedIndex--;
					if (SelectedIndex == -1)
					{
						SelectedIndex = Options.Length - 1;
					}
				}
				else if (keypressed == ConsoleKey.DownArrow)
				{
					//Console.Beep(800, 100);
					SelectedIndex++;
					if (SelectedIndex == Options.Length)
					{
						SelectedIndex = 0;
					}
				}

			} while (keypressed != ConsoleKey.Enter);
			return SelectedIndex;
		}
	}
}